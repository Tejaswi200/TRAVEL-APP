package com.android.travelapp;public class CourseDB {
}
