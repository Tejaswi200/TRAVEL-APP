package com.android.travelapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UpdateDeleteWisata extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_delete_wisata);
    }
}