package com.android.travelapp;public class Wisata {
}
