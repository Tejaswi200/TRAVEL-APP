package com.android.travelapp;public class DBWisata {
}
